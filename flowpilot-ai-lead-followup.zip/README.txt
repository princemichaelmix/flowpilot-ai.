FLOWPILOT AI — LEAD FOLLOW-UP MVP
===================================
This version focuses on saving leads, setting a follow-up date, tracking status, and preparing follow-up message drafts.

WHAT WORKS IN THIS FIRST VERSION
- Responsive phone/laptop interface
- Add, search, filter, update and delete leads
- Follow-up date field and dashboard counts
- Built-in follow-up message templates work without an API key
- Optional AI-personalized follow-up drafts using an OpenAI API key on the server

IMPORTANT LIMITATIONS
- Leads are stored in browser localStorage on this device only. Clearing browser data can erase them; they do not sync across devices or users.
- Follow-up dates are tracked in the app, but this version does NOT send timed notifications.
- Messages are not sent automatically. Users copy reviewed drafts into their normal messaging app.
- Do not upload real customer personal data to a public demo. Add authentication, server-side database access, privacy policy, and security controls before serving paying customers.

DEPLOY TO NETLIFY
1. Create a NEW GitHub repository named flowpilot-ai.
2. Upload index.html, netlify.toml, and the netlify/functions/followup.js file preserving its folder path.
3. In Netlify choose Add new site / Import an existing project, connect GitHub and select flowpilot-ai.
4. Build command: leave blank. Publish directory: .
5. Optional AI: Netlify site configuration > Environment variables > add OPENAI_API_KEY with your own key. Never put it in index.html or commit it to GitHub.
6. Redeploy, then test by adding a sample lead and generating a follow-up message.

COST / COMMERCIAL READINESS
OpenAI API usage may cost extra and is separate from a ChatGPT subscription. Before public paid launch, add rate limiting, authentication and usage limits.

NEXT FEATURES TO BUILD FOR A PAID MULTI-USER PRODUCT
- Account login and secure shared cloud database
- Real scheduled reminders (email or in-app)
- WhatsApp Business Platform integration only after the business connects and authorizes it, with consent and template rules respected
- Subscription/payment system and customer support
