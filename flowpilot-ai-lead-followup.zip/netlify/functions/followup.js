exports.handler = async (event) => {
  const headers = {"Content-Type":"application/json","Access-Control-Allow-Headers":"Content-Type","Access-Control-Allow-Methods":"POST, OPTIONS"};
  if (event.httpMethod === "OPTIONS") return {statusCode:204,headers,body:""};
  if (event.httpMethod !== "POST") return {statusCode:405,headers,body:JSON.stringify({error:"Use POST."})};
  const key = process.env.OPENAI_API_KEY;
  if (!key) return {statusCode:503,headers,body:JSON.stringify({error:"AI key is not configured. Using built-in templates instead."})};
  try {
    const p = JSON.parse(event.body || "{}");
    const allowed = ["gentle","quote","objection","close","thank"];
    const goalText = {gentle:"Write a friendly, low-pressure check-in.",quote:"Follow up on a quote or price enquiry.",objection:"Invite the lead to share concerns and answer without inventing facts.",close:"Help the lead decide without pressure or false urgency.",thank:"Thank a customer after purchase and offer appropriate help."};
    if (!p || typeof p !== "object" || (p.extra||"").length > 1500) return {statusCode:400,headers,body:JSON.stringify({error:"Invalid input."})};
    const lead = p.lead || {};
    const safe = {
      name: String(lead.name||"there").slice(0,100),
      interest: String(lead.interest||"your enquiry").slice(0,250),
      notes: String(lead.notes||"").slice(0,1000),
      business: String(p.business||"").slice(0,180),
      extra: String(p.extra||"").slice(0,1500),
      goal: goalText[allowed.includes(p.goal)?p.goal:"gentle"]
    };
    const r = await fetch("https://api.openai.com/v1/responses", {
      method:"POST",
      headers:{"Authorization":"Bearer "+key,"Content-Type":"application/json"},
      body:JSON.stringify({
        model:process.env.OPENAI_MODEL||"gpt-4.1-mini",
        instructions:"You write concise, respectful customer follow-up messages for a small business. Personalize the message, be honest, do not invent discounts, product features, deadlines, or promises. Avoid pressure, manipulative urgency, and spam. Output only the message, ready for the business owner to review and send. Goal: "+safe.goal,
        input:JSON.stringify(safe),
        max_output_tokens:450
      })
    });
    const data = await r.json();
    if(!r.ok) return {statusCode:502,headers,body:JSON.stringify({error:data.error?.message||"AI provider error."})};
    let result=data.output_text;
    if(!result&&Array.isArray(data.output)) result=data.output.flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n");
    return {statusCode:200,headers,body:JSON.stringify({result:result||"Please try again."})};
  } catch(e) { return {statusCode:500,headers,body:JSON.stringify({error:"Could not create the message. Please try again."})}; }
};