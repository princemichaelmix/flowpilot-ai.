-- FUTURE PRODUCTION SCHEMA DRAFT (not connected by this demo)
-- Enable Row Level Security and test policies before using real customer data.
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  contact text,
  interest text not null,
  source text,
  follow_up_date date,
  notes text,
  status text not null default 'New'
    check (status in ('New','Follow-up needed','Waiting for reply','Won','Lost')),
  created_at timestamptz not null default now(),
  last_follow_up_at timestamptz
);
alter table public.leads enable row level security;
create policy "Owners can view their leads" on public.leads
  for select to authenticated using (auth.uid() = owner_id);
create policy "Owners can insert their leads" on public.leads
  for insert to authenticated with check (auth.uid() = owner_id);
create policy "Owners can update their leads" on public.leads
  for update to authenticated using (auth.uid() = owner_id) with check (auth.uid() = owner_id);
create policy "Owners can delete their leads" on public.leads
  for delete to authenticated using (auth.uid() = owner_id);
